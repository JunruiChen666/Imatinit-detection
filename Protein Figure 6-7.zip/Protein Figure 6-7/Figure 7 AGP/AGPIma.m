clear all;
clc;
close all;
AGPIma1{1} = [0.45,0.42,0.37,0.34,0.31,0.28,0.38]; % 1
AGPIma1{2} = [0.3,0.15,0.21,0.21,0.23,0.28,0.34,0.09,0.12,0.11,0.19,0.28,0.32]; % 1
AGPIma1{3} = [1,2.01,0.78,0.7,1.38,1.51,1.4,1.44,1.36,1.5,1.86,1.82,1.29,1.38,1.45,1.9]; % 1

% x 轴
x = [0.1, 1,  10]; % 由于对数坐标不能包含0，最小值修改为0.01
positions2=[0.1, 1,  10]
% 计算每组的平均值和标准差
means0 = cellfun(@mean, AGPIma1);
std_devs0 = cellfun(@std, AGPIma1);

% 创建新图窗口
figure;


% 绘制每组数据的误差棒图
errorbar(x, means0, std_devs0, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'r');
hold on;
grid on;
legend('100uM Aptamer-1uM Imatinib binding Assay in buffer','Fontsize',12)
% for i = 1:3
%     % 绘制箱形图
%     boxplot(AGPIma1{i}, 'Positions', positions2(i), 'Widths', 0.5, ...
%             'Colors', 'b', 'MedianStyle', 'target', 'Whisker', Inf);
% 
%     % 绘制数据点
%     scatter(repmat( positions2(i), size(AGPIma1{i})), AGPIma1{i}, 5, 'b', 'filled', 'MarkerEdgeColor', 'b');
% 
% 
%     % 计算并存储平均值
%     means2(i) = mean(AGPIma1{i});
% end
% hold on;
% % 连接每组的平均值
% plot( positions2, means2, '-o', 'LineWidth', 1, 'Color', 'r', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r');
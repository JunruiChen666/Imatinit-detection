% 数据准备（示例数据）
AGP0Ima{1} = [0.02,0.04,0.18,0.04,0.01,0.02,0.01,0.04,0.16]; % 0
AGP0Ima{2} = [0.45,0.42,0.3,0.18,0.45,0.15,0.16,0.42,0.39,0.21,0.28,0.18,0.22,0.14,0.1]; % 0.1
AGP0Ima{3} = [0.45,0.42,0.37,0.34,0.31,0.28,0.38]; % 1
AGP0Ima{4} = [0.57,0.47,0.54,0.59,0.62,0.44,0.53,0.58,0.61,0.53]; % 2
AGP0Ima{5} = [0.82,0.84,0.79,0.83,0.79,0.83,0.78]; % 10V

% x 轴
x = [0.01, 0.1, 1, 2, 10]; % 由于对数坐标不能包含0，最小值修改为0.01

% 计算每组的平均值和标准差
means0 = cellfun(@mean, AGP0Ima);
std_devs0 = cellfun(@std, AGP0Ima);

% 创建新图窗口
figure;
hold on;

% 绘制每组数据的误差棒图
errorbar(x, means0, std_devs0, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'r');

% 1g/l 数据
AGP10Ima{1} = [0,0.01,0.01,0,0.03,0.02,0.04,0.02,0.03,0.05,0.02,0.04,0.02,0.08]; % 0
AGP10Ima{2} = [0.1,0.02,0.01,0,0.09,0,0.05,0.01,0.09,0.04,0.02,0.02,0.01,0.07,0.02]; % 0.1
AGP10Ima{3} = [0.3,0.15,0.21,0.21,0.23,0.28,0.34,0.09,0.12,0.11,0.19,0.28,0.32]; % 1
AGP10Ima{4} = [0.69,0.63,0.51,0.42,0.3,0.36,0.56,0.51,0.46,0.62,0.54,0.51]; % 2
AGP10Ima{5} = [0.78,0.73,0.7,0.59,0.63,0.69,0.69,0.86,0.64,0.74,0.66,0.78,0.85,0.74,0.64,0.98,0.74]; % 10V

means10 = cellfun(@mean, AGP10Ima);
std_devs10 = cellfun(@std, AGP10Ima);

errorbar(x, means10, std_devs10, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'b');

% 10g/l 数据
AGP100Ima{1} = [0.06,0.08,0.38,0.48,0.39,0.24,0.3,0.22,0.26,0.38]; % 0
AGP100Ima{2} = [1,2.01,0.78,0.7,1.38,1.51,1.4,1.44,1.36,1.5,1.86,1.82,1.29,1.38,1.45,1.9]; % 1

x_100 = [0.01, 1]; % 修改为对数坐标适合的 x 值范围

means100 = cellfun(@mean, AGP100Ima);
std_devs100 = cellfun(@std, AGP100Ima);

errorbar(x_100, means100, std_devs100, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'k');

% 设置 x 轴为半对数坐标
set(gca, 'XScale', 'log');

% 设置图例和标签
xlabel('Imatinib Concentration (V)');
ylabel('Voltage gap (Vg)');
legend('AGP 0.1g/l', 'AGP 1g/l', 'AGP 10g/l', 'Location', 'southeast');
title('Grouped Data with Error Bars (Mean ± Standard Deviation)');

% 打开网格
grid on;
hold off;

clear all;
clc;
close all;



Vg_5gl=[0.25,0.2,0.3,0.26,0.16,0.22,0.22,0.22,0.28,0.26,0.26,0.34,0.4,0.4,0.42,0.36,0.54];
Vg1=[0.24,0.12,0.3,0.28,0.32,0.6,0.14,0.34,0.44,0.26,0.4,0.28,0.18,0.18,0.22,0.26,0.26,0.38,0.2,0.46,0.42];
Vg5=[0.38,0.3,0.24,0.16,0.14,0.16,0.14,0.36,0.34,0.3,0.3];
Vg10=[0.27,0.23,0.41,0.43,0.35,0.27,0.25,0.12,0.09,0.27];
Vg20=[0.05,0.14,0.06,0.15,0.15,0.01,0.14,0.02,0.02,0.03,0.01];
Vg40=[1.46,1.47,0.75,0.85,1.08,1.04,0.87,0.63,0.59,0.69,0.92,1.55,0.79,1.04,1.62,0.41,0.82,1.98,1.15,1.53,0.86,1.06];

% group6 = [0.1, 0.03, 0.01,  0.87, 0.64, 0.01, 0, 0.51, 0.59, 0.1,0.1,0.45,0.03,0.48,0.25,0.34,0.25,0.45,0.49,0.54,0.43,0.08,0.53,0.17];
% group7 = [0.09,0,0.37,0.27,0.28,0.03,0.14,0,0.14];
data2 = { Vg_5gl, Vg1,Vg5,Vg10,Vg20,Vg40};
%x_positions2=[10,100];
%positions2=[1:6];
positions2=[0.5,1,5,10,20,40];
hold on;
for i = 1:6
    % 绘制箱形图
    boxplot(data2{i}, 'Positions', positions2(i), 'Widths', 0.5, ...
            'Colors', 'b', 'MedianStyle', 'target', 'Whisker', Inf);

    % 绘制数据点
    scatter(repmat( positions2(i), size(data2{i})), data2{i}, 5, 'b', 'filled', 'MarkerEdgeColor', 'b');


    % 计算并存储平均值
    means2(i) = mean(data2{i});
end
hold on;
% 连接每组的平均值
plot( positions2, means2, '-o', 'LineWidth', 1.5, 'Color', 'r', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r');

%legend('', '', '','Location', 'Best','fontsize',16);

%% Standard deviation
means0 = cellfun(@mean, data2);
std_devs0 = cellfun(@std, data2);

% 创建新图窗口
figure;
grid on

% 绘制每组数据的误差棒图
errorbar(positions2, means0, std_devs0, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'b');
hold on;
grid on
set(gca, 'XScale', 'log');
legend('100uM Aptamer-20uM Imatinib binding Assay in buffer','Fontsize',12)
% % 调整图形窗口大小
% set(gcf, 'Position', [100, 100, 1200, 400]); % 调整图形窗口的大小
clear all;
clc;
close all;

% 数据定义  Buffer
group5 = [ 0.31, 0.74, 0.76, 0.61, 1.03, 0.33, 0.45, 0.47, 0.76, 0.6,0.45, 0.41, 0.46, 0.55, 0.48, 0.51, 0.54, 0.96, 0.23];
group4 = [0.25,  0.52, 0.53, 0.61, 0.47,  0.27, 0.26, 0.28, 0.36, 0.22, 0.25, 0.26, 0.14, 0.15, 0.16, 0.36, 0.43, 0.39, 0.365, 0.38];
group3 = [ 0.12, 0.22,  0.32,0.32, 0.22,  0.25, 0.24,0.19, 0.24, 0.15, 0.26];
group2 = [0.15, 0.12, 0.17, 0.22, 0.17, 0.28,  0.22,  0.23,0.22, 0.21, 0.16];
group1 = [0.04, 0.08, 0.09,0.14,0.14,0.1, 0.11,0.13,0.1,0.08,];
group0 = [0.07,0,0.11,0.13,0.08,0.14,0.06,0.03,0.00,0.06, 0.08];
% 数据集合和对应的 x 轴位置
data = {group0, group1, group2, group3, group4, group5};
x_positions = [0.001, 0.01, 0.1, 1, 10, 100];

position1=[-3    -2    -1     0     0.75     1.75];


% 创建图形
figure;

% 绘制箱形图
hold on;
for i = 1:6
    % 绘制箱形图
    boxplot(data{i}, 'Positions', position1(i), 'Widths', 0.5, ...
            'Colors', 'k', 'MedianStyle', 'target', 'Whisker', Inf);
    
    % 绘制数据点
    scatter(repmat(position1(i), size(data{i})), data{i}, 2, 'k', 'filled', 'MarkerEdgeColor', 'k');


    % 计算并存储平均值
    means(i) = mean(data{i});
end
hold on;
% 连接每组的平均值
plot(position1, means, '-o', 'LineWidth', 1, 'Color', 'k', 'MarkerEdgeColor', 'k', 'MarkerFaceColor', 'k');
legend('1% Aptamer in 0.9% NaCl buffer solution', '', '', '', '', '', 'Location', 'Best','Fontsize',12);
hold on;

means0 = cellfun(@mean, data);
std_devs0 = cellfun(@std, data);

% 创建新图窗口
figure;
hold on;
grid off;

% % 绘制每组数据的误差棒图
 errorbar(x_positions, means0, std_devs0, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'r');
 set(gca, 'XScale', 'log');
 hold on;
%% plasma
 group6 = [0.57, 0.47, 0.18,  0.62, 0.48, 0.61, 0.51, 0.49, 0.51, 0.4];
group7 = [0.21, 0.25, 0.29, 0.19, 0.14, 0.08, 0.15, 0.14, 0.2, 0.17, 0.22, 0.18, 0.15, 0.13, 0.18];
group8 =[0.15, 0.12,0.13,0.13,0.08,0.15,0.08,0.1,0.12,0.14,0.18,0.15]
group9 = [0.11, 0.14,0.12,0.11,0.01,0.12,0.11,0.11,0.12,0.17,0.13,0.14]
group10 = [0.18, 0.16,0.16,0.07,0.08,0.05,0.12,0.11,0.06,0.12,0.13,0.11]
group11 = [0.11, 0.11,0.13,0.16,0.09,0.12,0.09,0.12,0.14,0.16,0.17,0.12]
% group9 = [0.11, 0.2,0.11,0.1,0.2,0.11,0.17,0.07,0.16,0.16,0.17,0.11]
% group10 = [0.19, 0.07,0.17,0.15,0.09,0.11,0.12,0.11,0.19,0.15,0.13,0.08]
% group11 = [0.12, 0.13,0.19,0.15,0.09,0.13,0.11,0.19,0.11,0.09,0.14,0.14]
data2 = {group11,group10,group9,group8,group7, group6};
means1= cellfun(@mean, data2);
std_devs1 = cellfun(@std, data2);
x_positions2 = [0.001, 0.01,0.1,1, 10, 100];
errorbar(x_positions, means1, std_devs1, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', 'b');
grid on;
% % 设置 x 轴为对数坐标
% set(gca, 'XScale', 'log');
% 
% % 设置 x 轴刻度和标签
% set(gca, 'XTick', x_positions, 'XTickLabel', {'0.01', '0.1', '1', '10', '100'});
% 
% % 设置标签和标题
% xlabel('对数坐标');
% ylabel('值');
% title('每组数据的箱形图及数据点');

% 添加图例
%legend('0.9% NaCl solution', '', '', '', '', '', 'Location', 'Best');



% hold on;
% group6 = [0.57, 0.47, 0.18,  0.62, 0.48, 0.61, 0.51, 0.49, 0.51, 0.4];
% group7 = [0.21, 0.25, 0.29, 0.19, 0.14, 0.08, 0.15, 0.14, 0.2, 0.17, 0.22, 0.18, 0.15, 0.13, 0.18];
% data2 = {group7, group6};
% x_positions2=[10,100];
% positions2=[1.25,2.25]
% hold on;
% for i = 1:2
%     % 绘制箱形图
%     boxplot(data2{i}, 'Positions', positions2(i), 'Widths', 0.5, ...
%             'Colors', 'r', 'MedianStyle', 'target', 'Whisker', Inf);
% 
%     % 绘制数据点
%     scatter(repmat( positions2(i), size(data{i})), data{i}, 5, 'r', 'filled', 'MarkerEdgeColor', 'r');
% 
% 
%     % 计算并存储平均值
%     means2(i) = mean(data2{i});
% end
% hold on;
% % 连接每组的平均值
% plot( positions2, means2, '-o', 'LineWidth', 1, 'Color', 'r', 'MarkerEdgeColor', 'r', 'MarkerFaceColor', 'r');
% hold on;
legend('1% Aptamer in 0.9% NaCl buffer solution', '1% Aptamer in plasma', '', '', '', '', '','palsma','Location', 'Best','Fontsize',12);

% % 调整图形窗口大小
% set(gcf, 'Position', [100, 100, 1200, 400]); % 调整图形窗口的大小